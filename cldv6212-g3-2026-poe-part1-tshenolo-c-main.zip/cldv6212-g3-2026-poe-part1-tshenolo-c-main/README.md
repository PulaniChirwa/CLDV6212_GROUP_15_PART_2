# cldv6212-g3-2026-poe-part1-tshenolo-c

# CoffeeNChill Canteen Management System - Part 1

## Project Overview
This project modernizes the CoffeeNChill campus canteen operations by replacing paper-based menus and filing cabinet documents with a cloud-enabled microservices foundation. 

This repository contains the Part 1 implementation, which includes:
- Azure Table Storage for dynamic digital menu items.
- Azure File Share for centralized staff documents (recipes, manuals, policies).
- HTTP-triggered Azure Functions** running locally in isolated Docker containers via Azurite emulation.

## 1.Local Setup Steps

### Prerequisites
- Docker Desktop installed and running.
- .NET 6.0 (or 8.0) SDK installed.
- Postman installed (for API testing).

### Installation & Configuration
- Clone the Repository:
   ```bash
  git clone (https://github.com/EMGPSD/cldv6212-g3-2026-poe-part1-tshenolo-c)
   cd (cldv6212-g3-2026-poe-part1-tshenolo-c)
   ```

##  2. Standalone Docker Execution Commands
(Note: No Docker Compose is used in Part 1, as per requirements. Containers must be run independently.)

Follow these steps to run the system manually using standalone Docker containers.

### Step 1: Run the Azurite Storage Emulator
Pull and run Azurite in its own isolated container, binding the default storage ports (10000 for Tables, 10001 for Blobs, 10002 for Queues):
```bash
docker run -p 10000:10000 -p 10001:10001 -p 10002:10002 mcr.microsoft.com/azure-storage/azurite
```

### Step 2: In a new terminal window, build the Docker image for the Azure Functions
```bash
docker build -t tshenoloc/coffeenchill-functions:v1.0.
```

### Step 3: Step 3: Run the Functions Container

Run the function container independently, passing the environment variable so it connects to the Azurite container host:
```bash
docker run -p 7071:80 -e AzureWebJobsStorage="UseDevelopmentStorage=true" [your-dockerhub-username]/coffeenchill-functions:v1.0
```
The Functions app will now be available at http://localhost:7071. 

## Group Contributions 
Lethabo (ST10456761) - Was responsible for the Menu Management functionality. Created the MenuItem model, MenuTableService, and the Azure Functions for creating, retrieving, filtering by category, updating and deleting menu items. I also configured dependency injection for the menu services, tested the CRUD Functionality using postman. 
Tshenolo (ST10469987) - Azurite and Docker integration, as well as adding the docker ignore document and Docker md document.
Pulani (ST10454181) - I was responsible for implementing the Azure Blob Storage staff-document functionality. Created the staff-docs container and developed the HTTP functions to upload, list and download staff documents, with file validation, metadata tracking and error handling. 
Karabo (ST10488555) - Formatted the README.md section, , /docs, Postman environment/ collection structure, contribution section, etc.
