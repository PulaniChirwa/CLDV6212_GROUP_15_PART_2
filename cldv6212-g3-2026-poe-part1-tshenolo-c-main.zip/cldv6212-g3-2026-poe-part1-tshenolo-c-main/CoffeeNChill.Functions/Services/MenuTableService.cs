using Azure;
using Azure.Data.Tables;
using CoffeeNChill.Functions.Models;

namespace CoffeeNChill.Functions.Services
{
    public class MenuTableService
    {
        private readonly TableClient _tableClient;

        public MenuTableService()
        {
            string connectionString =
                Environment.GetEnvironmentVariable("AzureWebJobsStorage")
                ?? "UseDevelopmentStorage=true";

            _tableClient = new TableClient(connectionString, "MenuItems");
            
        }

        
        private async Task EnsureTableExistsAsync()
        {
            await _tableClient.CreateIfNotExistsAsync();
        }

        public async Task AddMenuItemAsync(MenuItem item)
        {
            await EnsureTableExistsAsync(); 
            await _tableClient.AddEntityAsync(item);
        }

        public async Task<List<MenuItem>> GetAllMenuItemsAsync()
        {
            await EnsureTableExistsAsync(); 
            
            var items = new List<MenuItem>();

            await foreach (var item in _tableClient.QueryAsync<MenuItem>())
            {
                items.Add(item);
            }

            return items;
        }

        public async Task<List<MenuItem>> GetMenuItemsByCategoryAsync(string category)
        {
            await EnsureTableExistsAsync(); 
            
            var items = new List<MenuItem>();

            await foreach (var item in _tableClient.QueryAsync<MenuItem>(
                x => x.PartitionKey == category))
            {
                items.Add(item);
            }

            return items;
        }

        public async Task<MenuItem?> GetMenuItemAsync(string category, string id)
        {
            await EnsureTableExistsAsync(); 
            
            try
            {
                var response = await _tableClient.GetEntityAsync<MenuItem>(
                    category,
                    id
                );

                return response.Value;
            }
            catch (RequestFailedException ex) when (ex.Status == 404)
            {
                return null;
            }
        } 

        public async Task UpdateMenuItemAsync(MenuItem item)
        {
            await EnsureTableExistsAsync(); 
            
            await _tableClient.UpdateEntityAsync(
                item,
                ETag.All,
                TableUpdateMode.Replace
            );
        }

        public async Task DeleteMenuItemAsync(string category, string id)
        {
            await EnsureTableExistsAsync(); 
            
            await _tableClient.DeleteEntityAsync(category, id);
        }
    }
}
