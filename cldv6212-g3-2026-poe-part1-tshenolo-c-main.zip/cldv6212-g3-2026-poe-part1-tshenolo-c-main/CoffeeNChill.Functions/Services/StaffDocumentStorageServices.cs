﻿using Azure.Storage.Blobs;
using Azure.Storage.Blobs.Models;
using CoffeeNChill.Functions.Models;
using Microsoft.Extensions.Configuration;

namespace CoffeeNChill.Functions.Services
{
    public class StaffDocumentStorageService
    {
        // This is the name of the Azure Blob Storage container.
        private const string ContainerName = "staff-docs";

        private readonly BlobContainerClient _containerClient;

        public StaffDocumentStorageService(
            IConfiguration configuration)
        {
            string connectionString =
                configuration["AzureWebJobsStorage"]
                ?? throw new InvalidOperationException(
                    "The AzureWebJobsStorage connection string is missing.");

            _containerClient = new BlobContainerClient(
                connectionString,
                ContainerName);
        }

        public async Task UploadAsync(
            Stream fileStream,
            string fileName,
            string contentType)
        {
            await _containerClient.CreateIfNotExistsAsync(
                PublicAccessType.None);

            BlobClient blobClient =
                _containerClient.GetBlobClient(fileName);

            BlobUploadOptions options = new BlobUploadOptions
            {
                HttpHeaders = new BlobHttpHeaders
                {
                    ContentType = contentType
                },

                Metadata = new Dictionary<string, string>
                {
                    ["OriginalFileName"] = fileName,
                    ["UploadedOnUtc"] =
                        DateTimeOffset.UtcNow.ToString("O")
                }
            };

            await blobClient.UploadAsync(
                fileStream,
                options);
        }

        public async Task<List<StaffDocumentDto>> ListAsync()
        {
            await _containerClient.CreateIfNotExistsAsync(
                PublicAccessType.None);

            List<StaffDocumentDto> documents = new();

            GetBlobsOptions listOptions = new GetBlobsOptions
            {
                Traits = BlobTraits.Metadata
            };

            await foreach (BlobItem blob in
                           _containerClient.GetBlobsAsync(
                               listOptions))
            {
                documents.Add(new StaffDocumentDto
                {
                    FileName = blob.Name,
                    Size = blob.Properties.ContentLength ?? 0,
                    ContentType =
                        blob.Properties.ContentType
                        ?? "application/octet-stream",
                    LastModified = blob.Properties.LastModified,
                    DownloadUrl =
                        $"/api/documents/download/{Uri.EscapeDataString(blob.Name)}"
                });
            }

            return documents
                .OrderByDescending(
                    document => document.LastModified)
                .ToList();
        }

        public async Task<BlobDownloadStreamingResult?>
            DownloadAsync(string fileName)
        {
            BlobClient blobClient =
                _containerClient.GetBlobClient(fileName);

            if (!await blobClient.ExistsAsync())
            {
                return null;
            }

            return await blobClient.DownloadStreamingAsync();
        }
    }
}