﻿namespace CoffeeNChill.Functions.Models
{
    public class StaffDocumentDto
    {
        public string FileName { get; set; } = string.Empty;

        public long Size { get; set; }

        public string ContentType { get; set; } = string.Empty;

        public DateTimeOffset? LastModified { get; set; }

        public string DownloadUrl { get; set; } = string.Empty;
    }
}