﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.Functions.Worker;
using CoffeeNChill.Functions.Models;
using CoffeeNChill.Functions.Services;

namespace CoffeeNChill.Functions.Functions
{
    public class UpdateMenuItem
    {
        private readonly MenuTableService _menuTableService;

        public UpdateMenuItem(MenuTableService menuTableService)
        {
            _menuTableService = menuTableService;
        }

        [Function("UpdateMenuItem")]
        public async Task<IActionResult> Run(
            [HttpTrigger(AuthorizationLevel.Anonymous, "put",
            Route = "menu/{category}/{id}")] HttpRequest req,
            string category,
            string id)
        {
            var updatedItem = await req.ReadFromJsonAsync<MenuItem>();

            if (updatedItem == null)
            {
                return new BadRequestObjectResult("Invalid menu item data.");
            }

            var existingItem = await _menuTableService.GetMenuItemAsync(category, id);

            if (existingItem == null)
            {
                return new NotFoundObjectResult("Menu item not found.");
            }

            existingItem.Name = updatedItem.Name;
            existingItem.Description = updatedItem.Description;
            existingItem.Price = updatedItem.Price;
            existingItem.IsAvailable = updatedItem.IsAvailable;

            await _menuTableService.UpdateMenuItemAsync(existingItem);

            return new OkObjectResult(existingItem);
        }
    }
} 