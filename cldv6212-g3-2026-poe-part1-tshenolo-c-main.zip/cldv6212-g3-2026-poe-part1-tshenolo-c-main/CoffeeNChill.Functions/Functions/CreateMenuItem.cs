﻿using CoffeeNChill.Functions.Models;
using CoffeeNChill.Functions.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.Logging;
using System.Text.Json;

namespace CoffeeNChill.Functions.Functions
{
    public class CreateMenuItem
    {
        private readonly ILogger<CreateMenuItem> _logger;
        private readonly MenuTableService _menuTableService;

        public CreateMenuItem(
            ILogger<CreateMenuItem> logger,
            MenuTableService menuTableService)
        {
            _logger = logger;
            _menuTableService = menuTableService;
        }

        [Function("CreateMenuItem")]
        public async Task<IActionResult> Run(
            [HttpTrigger(AuthorizationLevel.Anonymous, "post", Route = "menu")]
            HttpRequest req)
        {
            try
            {
                string requestBody = await new StreamReader(req.Body).ReadToEndAsync();

                var menuItem = JsonSerializer.Deserialize<MenuItem>(
                    requestBody,
                    new JsonSerializerOptions
                    {
                        PropertyNameCaseInsensitive = true
                    });

                if (menuItem == null)
                {
                    return new BadRequestObjectResult("Invalid menu item data.");
                }

                if (string.IsNullOrWhiteSpace(menuItem.PartitionKey) ||
                    string.IsNullOrWhiteSpace(menuItem.RowKey) ||
                    string.IsNullOrWhiteSpace(menuItem.Name))
                {
                    return new BadRequestObjectResult(
                        "PartitionKey, RowKey and Name are required.");
                }

                await _menuTableService.AddMenuItemAsync(menuItem);

                return new OkObjectResult(menuItem);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error creating menu item.");

                return new ObjectResult("An error occurred while creating the menu item.")
                {
                    StatusCode = StatusCodes.Status500InternalServerError
                };
            }
        }
    }
} 