﻿using CoffeeNChill.Functions.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.Logging;

namespace CoffeeNChill.Functions.Functions
{
    public class DeleteMenuItem
    {
        private readonly ILogger<DeleteMenuItem> _logger;
        private readonly MenuTableService _menuTableService;

        public DeleteMenuItem(
            ILogger<DeleteMenuItem> logger,
            MenuTableService menuTableService)
        {
            _logger = logger;
            _menuTableService = menuTableService;
        }

        [Function("DeleteMenuItem")]
        public async Task<IActionResult> Run(
            [HttpTrigger(
                AuthorizationLevel.Anonymous,
                "delete",
                Route = "menu/{category}/{id}")]
            HttpRequest req,
            string category,
            string id)
        {
            try
            {
                var existingItem =
                    await _menuTableService.GetMenuItemAsync(category, id);

                if (existingItem == null)
                {
                    return new NotFoundObjectResult("Menu item not found.");
                }

                await _menuTableService.DeleteMenuItemAsync(category, id);

                return new OkObjectResult(
                    $"Menu item '{id}' deleted successfully.");
            }
            catch (Exception ex)
            {
                _logger.LogError(
                    ex,
                    "Error deleting menu item {Id} from category {Category}.",
                    id,
                    category);

                return new ObjectResult(
                    "An error occurred while deleting the menu item.")
                {
                    StatusCode = StatusCodes.Status500InternalServerError
                };
            }
        }
    }
} 