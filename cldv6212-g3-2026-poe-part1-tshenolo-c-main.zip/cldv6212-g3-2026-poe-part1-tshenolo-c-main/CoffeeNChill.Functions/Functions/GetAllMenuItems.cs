﻿using CoffeeNChill.Functions.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.Logging;

namespace CoffeeNChill.Functions.Functions
{
    public class GetAllMenuItems
    {
        private readonly ILogger<GetAllMenuItems> _logger;
        private readonly MenuTableService _menuTableService;

        public GetAllMenuItems(
            ILogger<GetAllMenuItems> logger,
            MenuTableService menuTableService)
        {
            _logger = logger;
            _menuTableService = menuTableService;
        }

        [Function("GetAllMenuItems")]
        public async Task<IActionResult> Run(
            [HttpTrigger(AuthorizationLevel.Anonymous, "get", Route = "menu")]
            HttpRequest req)
        {
            try
            {
                var items = await _menuTableService.GetAllMenuItemsAsync();

                return new OkObjectResult(items);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error retrieving menu items.");

                return new ObjectResult("An error occurred while retrieving menu items.")
                {
                    StatusCode = StatusCodes.Status500InternalServerError
                };
            }
        }
    }
} 