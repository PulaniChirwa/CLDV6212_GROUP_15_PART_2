﻿using CoffeeNChill.Functions.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.Logging;

namespace CoffeeNChill.Functions.Functions
{
    public class GetMenuItemsByCategory
    {
        private readonly ILogger<GetMenuItemsByCategory> _logger;
        private readonly MenuTableService _menuTableService;

        public GetMenuItemsByCategory(
            ILogger<GetMenuItemsByCategory> logger,
            MenuTableService menuTableService)
        {
            _logger = logger;
            _menuTableService = menuTableService;
        }

        [Function("GetMenuItemsByCategory")]
        public async Task<IActionResult> Run(
            [HttpTrigger(
                AuthorizationLevel.Anonymous,
                "get",
                Route = "menu/category/{category}")]
            HttpRequest req,
            string category)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(category))
                {
                    return new BadRequestObjectResult("Category is required.");
                }

                var items =
                    await _menuTableService.GetMenuItemsByCategoryAsync(category);

                return new OkObjectResult(items);
            }
            catch (Exception ex)
            {
                _logger.LogError(
                    ex,
                    "Error retrieving menu items for category {Category}.",
                    category);

                return new ObjectResult(
                    "An error occurred while retrieving menu items by category.")
                {
                    StatusCode = StatusCodes.Status500InternalServerError
                };
            }
        }
    }
} 