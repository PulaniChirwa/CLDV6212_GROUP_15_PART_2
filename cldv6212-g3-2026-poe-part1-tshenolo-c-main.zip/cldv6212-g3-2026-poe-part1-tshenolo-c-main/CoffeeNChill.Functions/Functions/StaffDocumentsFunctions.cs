﻿using Azure;
using CoffeeNChill.Functions.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.Logging;

namespace CoffeeNChill.Functions.Functions
{
    public class StaffDocumentsFunctions
    {
        // Maximum allowed document size: 10 MB
        private const long MaximumFileSize =
            10 * 1024 * 1024;

        // Document types permitted for upload
        private static readonly HashSet<string> AllowedExtensions =
            new HashSet<string>(StringComparer.OrdinalIgnoreCase)
            {
                ".pdf",
                ".doc",
                ".docx",
                ".txt"
            };

        private readonly StaffDocumentStorageService _storageService;
        private readonly ILogger<StaffDocumentsFunctions> _logger;

        public StaffDocumentsFunctions(
            StaffDocumentStorageService storageService,
            ILogger<StaffDocumentsFunctions> logger)
        {
            _storageService = storageService;
            _logger = logger;
        }

        // POST: /api/documents/upload
        [Function("UploadStaffDocument")]
        public async Task<IActionResult> UploadStaffDocument(
            [HttpTrigger(
                AuthorizationLevel.Anonymous,
                "post",
                Route = "documents/upload")]
            HttpRequest request)
        {
            try
            {
                if (!request.HasFormContentType)
                {
                    return new BadRequestObjectResult(new
                    {
                        message =
                            "The request must use multipart/form-data."
                    });
                }

                IFormCollection form =
                    await request.ReadFormAsync();

                IFormFile? file =
                    form.Files.GetFile("file");

                if (file == null || file.Length == 0)
                {
                    return new BadRequestObjectResult(new
                    {
                        message =
                            "No document was supplied. Use 'file' as the form-data key."
                    });
                }

                if (file.Length > MaximumFileSize)
                {
                    return new BadRequestObjectResult(new
                    {
                        message =
                            "The document exceeds the maximum size of 10 MB."
                    });
                }

                string safeFileName =
                    Path.GetFileName(file.FileName);

                if (string.IsNullOrWhiteSpace(safeFileName))
                {
                    return new BadRequestObjectResult(new
                    {
                        message = "The document name is invalid."
                    });
                }

                string extension =
                    Path.GetExtension(safeFileName);

                if (!AllowedExtensions.Contains(extension))
                {
                    return new BadRequestObjectResult(new
                    {
                        message =
                            "Only PDF, DOC, DOCX and TXT documents are allowed."
                    });
                }

                string contentType =
                    string.IsNullOrWhiteSpace(file.ContentType)
                        ? "application/octet-stream"
                        : file.ContentType;

                await using Stream fileStream =
                    file.OpenReadStream();

                await _storageService.UploadAsync(
                    fileStream,
                    safeFileName,
                    contentType);

                _logger.LogInformation(
                    "Staff document {FileName} uploaded successfully.",
                    safeFileName);

                return new CreatedResult(
                    $"/api/documents/download/{Uri.EscapeDataString(safeFileName)}",
                    new
                    {
                        message =
                            "Staff document uploaded successfully.",
                        fileName = safeFileName,
                        size = file.Length,
                        contentType = contentType,
                        downloadUrl =
                            $"/api/documents/download/{Uri.EscapeDataString(safeFileName)}"
                    });
            }
            catch (RequestFailedException exception)
            {
                _logger.LogError(
                    exception,
                    "Azure Blob Storage rejected the upload.");

                return new ObjectResult(new
                {
                    message =
                        "The document could not be uploaded to Blob Storage."
                })
                {
                    StatusCode =
                        StatusCodes.Status503ServiceUnavailable
                };
            }
            catch (Exception exception)
            {
                _logger.LogError(
                    exception,
                    "An unexpected upload error occurred.");

                return new ObjectResult(new
                {
                    message =
                        "An unexpected error occurred while uploading the document."
                })
                {
                    StatusCode =
                        StatusCodes.Status500InternalServerError
                };
            }
        }

        // GET: /api/documents
        [Function("ListStaffDocuments")]
        public async Task<IActionResult> ListStaffDocuments(
            [HttpTrigger(
                AuthorizationLevel.Anonymous,
                "get",
                Route = "documents")]
            HttpRequest request)
        {
            try
            {
                var documents =
                    await _storageService.ListAsync();

                return new OkObjectResult(new
                {
                    count = documents.Count,
                    documents = documents
                });
            }
            catch (Exception exception)
            {
                _logger.LogError(
                    exception,
                    "An error occurred while listing staff documents.");

                return new ObjectResult(new
                {
                    message =
                        "The staff documents could not be retrieved."
                })
                {
                    StatusCode =
                        StatusCodes.Status500InternalServerError
                };
            }
        }

        // GET: /api/documents/download/{fileName}
        [Function("DownloadStaffDocument")]
        public async Task<IActionResult> DownloadStaffDocument(
            [HttpTrigger(
                AuthorizationLevel.Anonymous,
                "get",
                Route = "documents/download/{fileName}")]
            HttpRequest request,
            string fileName)
        {
            try
            {
                string safeFileName =
                    Path.GetFileName(
                        Uri.UnescapeDataString(fileName));

                if (string.IsNullOrWhiteSpace(safeFileName))
                {
                    return new BadRequestObjectResult(new
                    {
                        message = "The document name is invalid."
                    });
                }

                var download =
     await _storageService.DownloadAsync(
         safeFileName);

                if (download is null)
                {
                    return new NotFoundObjectResult(new
                    {
                        message =
                            $"The document '{safeFileName}' was not found."
                    });
                }

                var downloadedDocument = download;

                string contentType =
                    downloadedDocument.Details.ContentType
                    ?? "application/octet-stream";

                return new FileStreamResult(
                    downloadedDocument.Content,
                    contentType)
                {
                    FileDownloadName = safeFileName
                };
            }
            catch (Exception exception)
            {
                _logger.LogError(
                    exception,
                    "An error occurred while downloading {FileName}.",
                    fileName);

                return new ObjectResult(new
                {
                    message =
                        "The staff document could not be downloaded."
                })
                {
                    StatusCode =
                        StatusCodes.Status500InternalServerError
                };
            }
        }
    }
}