using CoffeeNChill.Functions.Services; 
using Microsoft.Azure.Functions.Worker;
using Microsoft.Azure.Functions.Worker.Builder;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;

var builder = FunctionsApplication.CreateBuilder(args);

builder.ConfigureFunctionsWebApplication();
builder.Services.AddSingleton<MenuTableService>();
builder.Services.AddSingleton<StaffDocumentStorageService>();
builder.Build().Run(); 
